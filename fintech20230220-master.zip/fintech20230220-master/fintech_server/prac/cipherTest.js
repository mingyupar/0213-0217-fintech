var chipher = require("./caesar");
console.log(chipher.encrypt(6, "hi how are you I am fine"));
console.log(chipher.decrypt(98, "no nuc gxk eua O gs lotk"));
