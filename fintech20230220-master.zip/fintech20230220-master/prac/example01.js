var a = "test";
//private String a = "test";

let b = 28312873;
//private int b = 123858;

let c = 2312.785723;
//private double c = 123.51234524;
const d = "test2";

var a = "새로운 테스트";
// let c = 1234;
// 동일 변수명 선언 불가
// d = "reAssignment";
// 상수 재할당 불가

console.log(a);
console.log(b);
console.log(c);
console.log(d);
