let car = {
  name: "sonata",
  ph: 160,
  year: 2022,
};

const { name, ph, year } = car;

// let name = car.name;
// let ph = car.ph;
// let year = car.year;

console.log(name, ph, year);
