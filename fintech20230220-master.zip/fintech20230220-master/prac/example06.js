let car = {
  name: "sonata",
  ph: 160,
  year: 2022,
};

const { name, ph, year } = car;

console.log(name + "는 " + ph + " 마력 " + year + " 년식 입니다.");
console.log(`${name}는 ${ph} 마력 ${year} 년식 입니다.`);
